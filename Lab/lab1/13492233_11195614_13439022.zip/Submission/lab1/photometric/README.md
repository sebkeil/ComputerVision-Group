# Lab1 - Part1: Photometric stereo

## Instructions

- Extract the data in `photometrics_image.zip` to the same folder, namely `Lab1_Photometric_Color/photometric/`
- In `photometric_stereo.py`, set the path to the desired dataset folder
<!--stackedit_data:
eyJoaXN0b3J5IjpbMTAzNjMxMDM3MF19
-->